﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("mKIOGamedead")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("mK")]
[assembly: AssemblyProduct("mKIOGamedead")]
[assembly: AssemblyCopyright("Copyright © Encho Georgiev 20116")]
[assembly: AssemblyTrademark("mK")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("bbcd2750-9dc0-4887-bc3c-4a3db46be64e")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
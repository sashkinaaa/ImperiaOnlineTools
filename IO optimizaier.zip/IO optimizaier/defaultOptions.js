﻿var defaultOptions =
{
    isCheckForAttackEnabled: true,
    attackUnitsCount: "",
    isCheckForEspionageEnabled: true,
    isCheckForNotLoggedInEnabled: false,
    hideArmy: false,
    isAutoIncognitoEnabled: false,

    isCheckForAlliance_AttackEnabled: false,

    isAutoCutShortEnabled: true,
    isFestivalEnabled: false,
    isHideResourcesEnabled: false,
    isAutoHireEnabled: true,
    autoHireSettings: [2, 3, 4],

    isGoldRestrictionEnabled: false,
    goldRestrictionValue: "0",
    isAutoBuyWoodEnabled: false,
    autoBuyWoodValue: '0.5',
    isAutoBuyIronEnabled: false,
    autoBuyIronValue: '2.5',
    isAutoBuyStoneEnabled: false,
    autoBuyStoneValue: '1.0'
};
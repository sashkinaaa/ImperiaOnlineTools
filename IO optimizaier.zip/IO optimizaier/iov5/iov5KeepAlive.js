Executer.register({
    getTimeout: function () { return 10 * 1000; },
    getInitialTimeout: function () { return 10 * 1000; },
    exec: function (config) {
        if (config.isCheckForNotLoggedInEnabled) {
            Executer.post({
                n: "allBuildingsCutShort",
                f: function () {
                    var doc = document.implementation.createHTMLDocument();
                    doc.documentElement.innerHTML = this.responseText;
                    var logoutObj = doc.querySelector('[func="logoutAction"]');
                    if (!!logoutObj) {
                        var sound = document.createElement('embed');
                        sound.setAttribute('width', '5px');
                        sound.setAttribute('height', '5px');
                        sound.setAttribute('src', 'https://soundbible.com/mp3/Fire%20Truck%20Siren-SoundBible.com-642727443.mp3');
                        document.body.appendChild(sound);
                    }
                }
            });
        }
    }
});